USE [Event]
GO
/****** Object:  StoredProcedure [dbo].[SPEnquiry]    Script Date: 5/26/2021 7:45:48 PM ******/
DROP PROCEDURE [dbo].[SPEnquiry]
GO
/****** Object:  Table [dbo].[Enquiry]    Script Date: 5/26/2021 7:45:48 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Enquiry]') AND type in (N'U'))
DROP TABLE [dbo].[Enquiry]
GO
/****** Object:  Table [dbo].[Enquiry]    Script Date: 5/26/2021 7:45:48 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Enquiry](
	[EEID] [int] IDENTITY(1,1) NOT NULL,
	[EECname] [nvarchar](max) NULL,
	[EECPName] [nvarchar](13) NULL,
	[EECNumber] [nvarchar](30) NOT NULL,
	[EEEmail] [nvarchar](50) NOT NULL,
	[EEMessage] [nvarchar](max) NOT NULL,
	[EEstatus] [nvarchar](10) NOT NULL,
	[EERemark] [nvarchar](max) NULL,
	[EECreated] [date] NULL,
	[EECreatedBy] [nvarchar](50) NULL,
	[EEUpdated] [date] NULL,
	[EEUpdatedBy] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[EEID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[SPEnquiry]    Script Date: 5/26/2021 7:45:48 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 CREATE proc [dbo].[SPEnquiry]
@EEID nvarchar(50)=null,  
@EECname nvarchar(max)=null, 
@EECPName nvarchar(13)=null, 
@EECNumber nvarchar(30)=null, 
@EEEmail nvarchar(50)=null, 
@EEMessage nvarchar(max)=null, 
@EEstatus nvarchar(10)=null, 
@EERemark nvarchar(max)=null,  
@EECreatedBy nvarchar(50)=null,  
@EEUpdatedBy nvarchar(50)=null,

@ColName nvarchar(50)=null, 
@FilterValue nvarchar(50)=null, 
@User nvarchar(50)=null,  
@OrderBy nvarchar(50)=null,  
@ShortOrder nvarchar(50)=null, 


@RequestType nvarchar(15)

as

 
declare @query nvarchar(max)
declare @WhereClouse nvarchar(200)
declare @filtercondition nvarchar(max)



if lower(@RequestType)='add'
begin
INSERT INTO [dbo].[Enquiry]
           ([EECname]
           ,[EECPName]
           ,[EECNumber]
           ,[EEEmail]
           ,[EEMessage]
           ,[EEstatus]
           ,[EECreated]
           ,[EECreatedBy])
     VALUES
           (@EECname, 
           @EECPName,
           @EECNumber, 
           @EEEmail, 
           @EEMessage,
           @EEstatus, 
           GETDATE(),
           @EECreatedBy)
END

if lower(@RequestType)='getall'
begin

print 1

 set @WhereClouse = case when @User = 'admin@gmail.com' then ' 1=1 ' else ' EECreatedBy='''+ @User+'''' end;

 if(lower(@ColName) !='all')
	 begin
print 2
		set @WhereClouse = @WhereClouse + ' and '+ @ColName +'='''+@FilterValue+''''
	 end 
  
 set @OrderBy = case when @OrderBy is null then ' 1 ' else ' '+ @OrderBy+' ' end;
 set @ShortOrder = case when @ShortOrder is null then ' desc ' else ' '+ @ShortOrder+' ' end;
 
print 3
  print (@WhereClouse)
  print (@OrderBy)
  print (@ShortOrder)

set @query=N'SELECT [EEID]
      ,[EECname]
      ,[EECPName]
      ,[EECNumber]
      ,[EEEmail]
      ,[EEMessage]
      ,[EEstatus]
      ,[EERemark]
      ,[EECreated]
      ,[EECreatedBy]
      ,[EEUpdated]
      ,[EEUpdatedBy]
  FROM [dbo].[Enquiry] 
  where '+ @WhereClouse +'
  order by '+ @OrderBy +' '+  @ShortOrder

  print (@query)
  exec (@query)

END

if lower(@RequestType)='getone'
begin 
SELECT [EEID]
      ,[EECname]
      ,[EECPName]
      ,[EECNumber]
      ,[EEEmail]
      ,[EEMessage]
      ,[EEstatus]
      ,[EERemark]
      ,[EECreated]
      ,[EECreatedBy]
      ,[EEUpdated]
      ,[EEUpdatedBy]
  FROM [dbo].[Enquiry] 
  where EEID=@EEID
END
 
if lower(@RequestType)='delete'
begin  
DELETE FROM [dbo].[Enquiry] 
  where EEID=Convert(int,@EEID)
END

 
if lower(@RequestType)='update'
begin 


 set @EEUpdatedBy = case when @EEUpdatedBy is null then @User else @EEUpdatedBy end;

UPDATE [dbo].[Enquiry]
   SET 
      [EEstatus] = @EEstatus,  
      [EERemark] = @EERemark ,
      [EEUpdated] =  getdate(),
      [EEUpdatedBy] = @EEUpdatedBy
 
  where EEID= Convert(int,@EEID)
END


GO
