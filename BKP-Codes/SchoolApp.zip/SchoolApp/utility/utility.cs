﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.IO;
using System.Data.OleDb;
using System.Configuration;
using System.Data.SqlClient;

namespace SchoolApp.SchoolAppUtility
{
    public class AppKeyValueParam
    {
        public string keyfield { get; set; }
        public string valfield { get; set; }
    }
    public class AppUtility
    { 
        OleDbConnection Econ;
        SqlConnection con;
        string constr, Query, sqlconn;


        string sqlcon = ConfigurationManager.ConnectionStrings["sqlcon"].ToString();
         
        private Random random = new Random();
        public string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
            .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public DataTable getdata(string spname, List<AppKeyValueParam> param)
        {
            try
            {
                using (var con = new SqlConnection(sqlcon))
                {
                    using (var cmd = new SqlCommand(spname, con))
                    {
                        foreach (AppKeyValueParam item in param)
                        {
                            cmd.Parameters.AddWithValue(item.keyfield.Trim(), item.valfield.Trim());
                        }

                        cmd.CommandType = CommandType.StoredProcedure;

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();

                            con.Open();
                            da.Fill(dt);
                            con.Close();

                            return dt;
                        }
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        public int save(string spname, List<AppKeyValueParam> param)
        {
            try
            {
                using (var con = new SqlConnection(sqlcon))
                {
                    using (var cmd = new SqlCommand(spname, con))
                    {
                        foreach (AppKeyValueParam item in param)
                        {
                            cmd.Parameters.AddWithValue(item.keyfield.ToString(), item.valfield.ToString().Trim());
                        }

                        cmd.CommandType = CommandType.StoredProcedure;

                        con.Open();
                        int effectedRows = cmd.ExecuteNonQuery();
                        con.Close();

                        return effectedRows;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        #region Import from Excel File
        public void ExcelConn(string FilePath)
        {
            constr = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""", FilePath);
            Econ = new OleDbConnection(constr);

        }
        public void connection()
        { 
            con = new SqlConnection(sqlcon); 
        }
        public void InsertExcelRecords(string FilePath)
        {
            ExcelConn(FilePath);

            Query = string.Format("Select [Name],[City],[Address],[Designation] FROM [{0}]", "Sheet1$");
            OleDbCommand Ecom = new OleDbCommand(Query, Econ);
            Econ.Open();

            DataSet ds = new DataSet();
            OleDbDataAdapter oda = new OleDbDataAdapter(Query, Econ);
            Econ.Close();
            oda.Fill(ds);
            DataTable Exceldt = ds.Tables[0];
            connection();
            //creating object of SqlBulkCopy    
            SqlBulkCopy objbulk = new SqlBulkCopy(con);
            //assigning Destination table name    
            objbulk.DestinationTableName = "Employee";
            //Mapping Table column    
            objbulk.ColumnMappings.Add("Name", "Name");
            objbulk.ColumnMappings.Add("City", "City");
            objbulk.ColumnMappings.Add("Address", "Address");
            objbulk.ColumnMappings.Add("Designation", "Designation");
            //inserting Datatable Records to DataBase    
            con.Open();
            objbulk.WriteToServer(Exceldt);
            con.Close();
        }
        #endregion

    }
}